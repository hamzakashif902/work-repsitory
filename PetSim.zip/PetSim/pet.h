#pragma once
// The Header file of pet class 
using namespace std; // Standard file string datatype 
#ifndef PET_H // File Guards for Good practice
#define PET_H // File Guards for Good practice
// Declaring the class pet
class pet {       
// Declaring the data members for pet class
private:
	int hungerLevel;
	int boredomLevel;
	string  name ;
// Declaring private member function for class 
	int petMood();  // function to check to claculate the sum of hunger and boredom level
	void passTime(int intime = 1);   // function to stimulate the change in levels automatically to show passage of time
public:
// Declaring public member function for pet class 
	pet(int hungerLevel, int boredomLevel, string  name);  // parameterized constructor
	void set_hungerLevel(int hungerLevel);  //  set function for hunger level data member
	void set_boredomLevel(int boredomLevel);  // set function for boredom level
	void set_name(string name);    // set function for name data member
	int get_hungerLevel();   //  get function for hunger level data member
	int get_boredomLevel();  //  get function for boredom level data member
	string get_name();       //  get function for  name data member
	void talk();             //   function to check the status of your pet
	void feedPet(int decrease = 3);   //  function for feeding the pet to reduce the hunger level
	void play(int decrease = 3);      //  function for playing with the pet to reduce the boredom level
	void displayPetBehaviour();       //  function for displaying the mood of pet deponding upon pet hunger and boredom level
	void menu();           //   function select the option that what you want to do with your pet
};
#endif  // ending the File Guard for header file 