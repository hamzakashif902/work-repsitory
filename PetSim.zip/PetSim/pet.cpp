// defining / implemetation of the class pet 
#include<iostream>
#include<string.h>
#include<string>
#include"pet.h" // header file of pet class
using namespace std;
// parameterized constructor of pet class
pet::pet(int hungerLevel, int boredomLevel, string name) {
	this->hungerLevel = hungerLevel;
	this->boredomLevel = boredomLevel;
	this->name = name;
	cout << "The name of pet is " << name << endl;
	cout << "The initial hunger level of pet is " << hungerLevel << endl;
	cout << "The initial boredom level of pet is " << boredomLevel<<endl;
}
//  defination of set function for boredom level data member
void pet::set_boredomLevel(int boredomLevel) {
	this->boredomLevel = boredomLevel;
}
//  defination of set function for hunger level data member
void pet::set_hungerLevel(int hungerLevel) {
	this->hungerLevel = hungerLevel;
}
//  defination of set function for name  data member
void pet::set_name(string name) {
	this->name = name;
}
//    defination for get function for boredom level data member
int pet::get_boredomLevel() {
	return this->boredomLevel;
}
//    defination for get function for hunger level data member
int pet::get_hungerLevel() {
	return this->hungerLevel;
}
//    defination for get function for name data member
string pet::get_name() {
	return this->name;
}
//     defination for function to calculate the sum of boredom and hunger level
int pet::petMood() {
	return get_hungerLevel()+ get_boredomLevel();
}
//    defination for displaying the mood of the pet deponding upon hunger and boredom level
void pet::displayPetBehaviour() {
	int temp, temp2;
	temp = temp2 = 0;
	temp = get_boredomLevel();
	temp2 = get_hungerLevel();
	if (temp < 3 && temp2 < 3) {
		cout << "The pet is neither bore nor hungry" << endl;
	}
	else if (temp > 3 && temp <= 11) {
		cout << "The pet is a little bored " << endl;
	}
	else if (temp > 11) {
		cout << "The pet is very much bored" << endl;
	}
	else if (temp2 > 3 && temp2 <= 11) {
		cout << "The pet is a little hungry " << endl;
	}
	else if (temp2 > 11) {
		cout << "The pet is very much hungry" << endl;
	}
}
//    defination to increase the value of level to automatically with passage of time
void pet::passTime(int intime) {
	int temp = 0;
	temp = get_boredomLevel();
	temp = get_boredomLevel() + intime;
	set_boredomLevel(temp);
	temp = 0;
	temp = get_hungerLevel();
	temp = hungerLevel + intime;
	set_hungerLevel(temp);
}
//   defination of function to check the status of your pet
void pet::talk() {
	int intime = 2;
	if (petMood() < 7) {
		cout << "Pet is in happy mood"<<endl;
	}
	else if (petMood() > 7 && petMood() < 16) {
		cout << "Pet is in okay mood"<<endl;
	}
	else if (petMood() > 16 && petMood() < 21) {
		cout << "Pet is in frustrated mood"<<endl;
	}
	else if (petMood() > 21) {
		cout << "Pet is in mad mood"<<endl;
	}
	displayPetBehaviour();  //  calling the display function
	passTime(intime);   //   calling the time stimulation function
}
//  defination of function for feeding the pet to reduce the hunger level
void pet::feedPet(int decrease) {
	int temp = 0;
	int temp2 = 0;
	int intime = 2;
	temp = get_hungerLevel();
	temp2 = get_hungerLevel();
	temp = temp - decrease;
	if (temp > 0) {
		set_hungerLevel(temp);
		cout << "Pet has been fed" << endl;
	}
	else if (get_boredomLevel() < 100 || get_boredomLevel() > 0) {
		cout << "Your dog needed to be played immiegiately" << endl;
	}
	else{
		cout << "Pet can't be fed";
		set_hungerLevel(temp2);
	}
	displayPetBehaviour();    //   calling the display function
	passTime(intime);     //   calling the time stimulation function
}
// defination of function for playing with the pet to reduce the boredom level
void pet::play(int decrease) {
	int temp = 0;
	int temp2 = 0;
	int intime = 2;
	temp = get_boredomLevel();
	temp2 = get_boredomLevel();
	temp = temp - decrease;
	if (temp > 0) {
		set_boredomLevel(temp);
		cout << "Pet is enjoyed the play" << endl;
	}
	else if (get_hungerLevel() < 100 || get_hungerLevel()>0) {
		cout << "Your dog needed to be fed immiegiately" << endl;
	}
	else{
		cout << "Pet can't be played anymore" << endl;
		set_boredomLevel(temp2);
	}
	displayPetBehaviour();  //   calling display function 
	passTime(intime);       //   calling time stimulation function
}
//  defination of function to select the option that what you want to do with your pet
void pet::menu() {
	// interface to ask user that what is want to do to his pet
	cout << "Enter from the options bellow that what do you want to do with your pet" << endl;
	cout << "Enter "<<"1"<<" If you want to play with the pet" << endl;
	cout << "Enter "<<"2"<<" If you want to fed with the pet" << endl;
	cout << "Enter "<<"3"<<" If you want to talk with the pet" << endl;
	cout << "Enter "<<"4"<<" If you want to quit with the game" << endl;
	int option = 0;
	start:   //  label for user to continue playing unless he want to quit playing
	cout << "Enter the option" << endl;
	cin >> option;
	// condition for checking what the user want to do the us
	if (option == 1) {
		play();
		goto start;
	}
	else if (option == 2) {
		feedPet();
		goto start;
	}
	else if (option == 3) {
		talk();
		goto start;
	}
	else if (option == 4) {
		cout << "Okay Game Ended.Thx" << endl;
	}
	else {
		cout << "You have Entered the invalid option!" << endl << "Enter again" << endl;
		goto start;
	}
}
