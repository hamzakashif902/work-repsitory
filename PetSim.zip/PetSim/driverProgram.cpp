//  The driver function for the program 
#include<iostream>
#include <string>
#include"pet.h"
using namespace std;
// main function for the project
int main() {

	string name;
	int initialHungerlevel, initialBoredomlevel;
	//  taking initial input from the user
	cout << "Enter the name of your pet" << endl;
	getline(cin, name);
	cout << "Enter the initial hunger level of your pet" << endl;
	cin >> initialHungerlevel;
	cout << "Enter the initial boredom level of your pet" << endl;
	cin >> initialBoredomlevel;
	// declaring the object of the pet class
	pet myPet(initialHungerlevel,initialBoredomlevel,name);
	//  menu of what options you want to pick and what you want to do
	myPet.menu();
	return 0;
}
